# MemoryGuard Business package

## What's included
- Full MemoryGuard source (memoryguard/)
- Business threat list
- Activation client (scripts/activate.py)
- Licence public key (memoryguard/license_public_key.pem)
- Install docs

## Threat list
This Business build fetches an updated threat list from the MemoryGuard control plane (https://memoryguard-funnel.bryansmall26.workers.dev/v1/threats?tier=business). The list is refreshed weekly. An internet connection is required to receive threat updates.

## Activation
To activate your Business licence, run:
  python scripts/activate.py --server https://memoryguard-funnel.bryansmall26.workers.dev --license-key <YOUR_KEY>

## Install
Run:
  python scripts/self_install.py --with-mcp

Then open the dashboard at http://127.0.0.1:43847
