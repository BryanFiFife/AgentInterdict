# MemoryGuard Community package

## What's included
- Full MemoryGuard source (memoryguard/)
- Community threat list
- Activation client (scripts/activate.py)
- Licence public key (memoryguard/license_public_key.pem)
- Install docs

## Threat list
This Community build ships a static, baked-in threat list. It does not require a network connection to scan.

## Activation
Community is free and needs no activation key.

## Install
Run:
  python scripts/self_install.py --with-mcp

Then open the dashboard at http://127.0.0.1:43847
